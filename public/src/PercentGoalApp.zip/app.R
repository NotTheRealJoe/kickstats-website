#
# This is a Shiny web application. You can run the application by clicking
# the 'Run App' button above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/
#

library(shiny)

# Define UI for application that draws a histogram
ui <- fluidPage(
  
  # Application title
  titlePanel("What percent of your goal will your Kickstarter project make?"),
  
  # Sidebar with a slider input for number of bins 
  sidebarLayout(
    sidebarPanel(
      numericInput(inputId = "usdGoal", label = "Project Goal (USD) (Less than $500k):", value = 0, min = 0, max = 500000),
      selectInput(inputId = "category", label = "Main Category", choices = c("Art", "Music", "Comics", "Theater", "Dance", "Design", "Film & Video", "Food", "Photography", "Publishing", "Technology", "Journalism", "Crafts", "Games", "Fashion")),
      selectInput(inputId = "sponser", label = "Is your project a Kickstarter Staff Pick?", choices = c("Yes", "No")),
      submitButton(text = "Submit", icon(name = "calculator"))
    ),
    mainPanel(textOutput(outputId = "percent"), textOutput(outputId = "pledged"), imageOutput(outputId = "funPic"))
  )
)


server <- function(input, output) {
  output$pledged <- renderText({
    source("CleaningToNow.R")
    t <- intercept
    x <- findCoeff(input$category)
    y <- findGoal(input$usdGoal)
    z <- findSP(input$sponser)
    d <- t + x + y + z
    
    dC <- function(d){
      if(d <= 0){
        d = 0
      }
      else {
        d = d
      }
      return(d)
    }
    
    
    
    dC2 <- dC(d) 
    ds <- dC2*input$usdGoal
    dCheck <- round(ds, digits = 2)
    
    paste0("You will have approximately $", dCheck, " pledged to your project.") 
  })


  output$percent <- renderText({
    source("CleaningToNow.R")
    t <- intercept
    x <- findCoeff(input$category)
    y <- findGoal(input$usdGoal)
    z <- findSP(input$sponser)
    d <- t + x + y + z
    
    dC <- function(d){
      if(d <= 0){
        d = 0
      }
      else {
        d = d
      }
      return(d)
    }
    
    dC2 <- dC(d)*100
    dCheck <- round(dC2, digits = 2)
    
    
    paste0("You will make approximately ", dCheck, "% of your goal.") 
  })
  
  output$funPic <- renderImage(deleteFile = FALSE, expr = {
    source("CleaningToNow.R")
    t <- intercept
    x <- findCoeff(input$category)
    y <- findGoal(input$usdGoal)
    z <- findSP(input$sponser)
    d <- t + x + y + z
    
    dC <- function(d){
      if(d <= 0){
        d = 0
      }
      else {
        d = d
      }
      return(d)
    }
    
    r <- dC(d)
    
 if(r < 1){
   return(list(
     src = "failed.png",
     filetype = "image/png",
     alt = "Failed Project :(",
     style = "height:25vh"
   ))
 }
    else if(r >= 1){
      return(list(
        src = "successful.PNG",
        filetype = "image/png",
        alt = "Successful Project! :)",
        style = "height:25vh"
      ))
      
    }
    
    
  })
}


# Run the application 
shinyApp(ui = ui, server = server)