
#Loading and cleaning the data
load("k2018new.rda")
k2018_new$year <- as.numeric(format(k2018_new$launch, format = "%Y"))
k2018 <- k2018_new

#Creating Indicator Variables
k2018$spIndicator <- ifelse(k2018$staff_pick == "TRUE", 1, 0)
k2018$comic <- ifelse(k2018$mainCategory == "Comics", 1, 0)
k2018$dance <- ifelse(k2018$mainCategory == "Dance", 1, 0)
k2018$theater <- ifelse(k2018$mainCategory == "Theater", 1, 0)
k2018$design <- ifelse(k2018$mainCategory == "Design", 1, 0)
k2018$fashion <- ifelse(k2018$mainCategory == "Fashion", 1, 0)
k2018$filmVideo <- ifelse(k2018$mainCategory == "Film & Video", 1, 0)
k2018$food <- ifelse(k2018$mainCategory == "Food", 1, 0)
k2018$games <- ifelse(k2018$mainCategory == "Games", 1, 0)
k2018$music <- ifelse(k2018$mainCategory == "Music", 1, 0)
k2018$photography <- ifelse(k2018$mainCategory == "Photography", 1, 0)
k2018$journalism <- ifelse(k2018$mainCategory == "Journalism", 1, 0)
k2018$technology <- ifelse(k2018$mainCategory == "Technology", 1, 0)
k2018$crafts <- ifelse(k2018$mainCategory == "Crafts", 1, 0)
k2018$art <- ifelse(k2018$mainCategory == "Art", 1, 0)
k2018$publishing <- ifelse(k2018$mainCategory == "Publishing", 1, 0)

#Creating a linear model
#Removing Outliers
k2018NO <- k2018[-which(k2018$percentGoal >= 500), ]
k2018NO <- k2018NO[-which(k2018NO$usdPledged >= 500000), ]
k2018NO <- k2018NO[-which(k2018NO$usdGoal >= 500000), ]

#Using Category, Staff Pick, and Goal Amount
model <- lm(k2018NO$percentGoal ~ k2018NO$spIndicator + k2018NO$comic + k2018NO$dance + k2018NO$theater + k2018NO$journalism + k2018NO$technology + k2018NO$crafts + k2018NO$design + k2018NO$fashion + k2018NO$filmVideo + k2018NO$food + k2018NO$games + k2018NO$music + k2018NO$publishing + k2018NO$art  + k2018NO$usdGoal)

coeffs <- summary.lm(model)$coefficients
coeffsDF <- data.frame(coeffs)
coeffsDF$label <- c("Intercept", "SP", "Comics", "Dance", "Theater", "Journalism", "Technology", "Crafts", "Design", "Fashion", "Film & Video", "Food", "Games", "Music", "Art", "Photography", "usdGoal")
coeffsDF$Estimate <- as.numeric(coeffsDF$Estimate)

#Function for category
findCoeff <- function(Mcategory){
  if(Mcategory == "Photography"){
   return(0) 
  }
  else{
    coeffRow <- coeffsDF[which(coeffsDF$label == Mcategory), ]
    return(coeffRow$Estimate)
  }
}

#Function for SP
findSP <- function(isSP){
  coeffRow <- coeffsDF[which(coeffsDF$label == "SP"), ]
  if(isSP == "Yes"){
    return(coeffRow$Estimate)
  }
  else
    return(0)
}

#Function for Goal
findGoal <- function(GoalAmount){
  coeffRow <- coeffsDF[which(coeffsDF$label == "usdGoal"), ]
  coeffN <- coeffRow$Estimate
  mathGoal <- coeffN*GoalAmount
  return(mathGoal)
}

#Find Intercept
interceptL <- coeffsDF[which(coeffsDF$label == "Intercept"), ]
intercept <- interceptL$Estimate

