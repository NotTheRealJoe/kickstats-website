import requests
import json
import urllib
import time
import random

def is_ascii(s):
    # Determine whether a string contains non-ASCII characters. This is used to skip projects that have non-ASCII
    # characters in their name, as urllib will fail to encode them.
    #
    # From https://stackoverflow.com/questions/196345/how-to-check-if-a-string-in-python-is-in-ascii
    return all(ord(c) < 128 for c in s)


def http_get(url):
    headers = {
        ':authority:': 'www.kickstarter.com',
        'referrer': 'https://www.kickstarter.com/discover/advanced',
        'accept': 'application/json',
        'x-requested-with': 'XMLHttpRequest',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36'
    }
    page = requests.get(url, headers)
    assert page.status_code == 200
    return page


def get_project_creator(project_name, project_id):
    if not is_ascii(project_name):
        return

    project_id = int(project_id)

    #time.sleep(random.random() * 0.5)

    dat = json.loads(http_get("https://www.kickstarter.com/discover/advanced?google_chrome_workaround&term=" +
                              urllib.quote_plus(project_name) +
                              "&sort=magic&seed=2580500&page=1&format=json").content)

    if len(dat["projects"]) < 1:
        return

    if dat["projects"][0]["id"] != project_id:
        return

    return {
        "creator_id": dat["projects"][0]["creator"]["id"],
        "creator_name": dat["projects"][0]["creator"]["name"],
        "staff_pick": dat["projects"][0]["staff_pick"],
        "blurb": dat["projects"][0]["blurb"],
        "image_url": dat["projects"][0]["photo"]["full"],
        "country": dat["projects"][0]["location"]["country"]
    }
