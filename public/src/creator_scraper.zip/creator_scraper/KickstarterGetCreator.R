# install.packages("rPython")

library(rPython)

load("KickstarterData.rdata")

python.load("SearchForCreator.py")

for(i in 1:nrow(X2018)) {
  print(paste("Record", i, "of", nrow(X2018), paste(round((i/nrow(X2018))*100, 2), "%", sep = ""), sep = " "))
  
  # If we have already processed this row, skip it. Need to remove this if we want to run again and override/update.
  if(!is.na(X2018[i, "creator_id"])) next
  
  # Keep a list of projects where the Python program errors out (likely due to an unexpected response from the server)
  possibleError <- tryCatch({
    r <- python.call("get_project_creator", X2018[i, "name"], as.character(X2018[i, "ID"]))
  }, error = function(e) {
    append(failures, X2018[i, "ID"])
  })
  
  # If the Python call in the tryCatch above failed, continue to the next iteration
  # https://stackoverflow.com/questions/8093914/use-trycatch-skip-to-next-value-of-loop-upon-error
  if(inherits(possibleError, "error")) next
  
  X2018[i, "creator_name"] <- ifelse(length(r$creator_name) > 0, r$creator_name, NA)
  X2018[i, "staff_pick"] <- ifelse(length(r$staff_pick) > 0, r$staff_pick, NA)
  X2018[i, "country"] <- ifelse(length(r$country) > 0, r$country, NA)
  X2018[i, "creator_id"] <- ifelse(length(r$creator_id) > 0, r$creator_id, NA)
  X2018[i, "image_url"] <- ifelse(length(r$image_url) > 0, r$image_url, NA)
  X2018[i, "blurb"] <- ifelse(length(r$blurb) > 0, r$blurb, NA)
  
  # Save every 500 rows
  if(i %% 500 == 0) {
    save(X2018, failures, file = "KickstarterData.rdata")
  }
  
  # Introduce pauses with some degree of randomness at a variety of intervals throughout the iterations. Reduces excess
  # load on the server, and also prevents us from looking like we are conducting a DOS attack.
  if(i %% 10000000 == 0) {
    # Wait 10 to 20 minutes every 100K iterations
    t <- runif(1, 600, 1200)
  } else if(i %% 10000 == 0) {
    # Wait 2 to 7 minutes every 10K iterations
    t <- runif(1, 120, 420)
  } else if (i %% 1000 == 0) {
    # Wait 5 to 10 seconds every 1K iterations
    t <- runif(1, 5, 10)
  } else if(runif(1, 0, 1) > 0.85) {
    # 15% chance of waiting between 0 and 1 seconds every iteration
    # Using a 15 percent chance instead of just doing it every 7 (100 / 15) iterations is intended to make the requests
    # look more human to the server. Again, this is to prevent us from looking like a DOS attack.
    t <- runif(1, 0, 1)
  } else {
    t = 0
  }
  if(t > 0) {
    print(paste("Waiting for", t, "seconds", sep = " "))
    Sys.sleep(t)
  }
}

save(X2018, failures, file = "KickstarterData.rdata")
