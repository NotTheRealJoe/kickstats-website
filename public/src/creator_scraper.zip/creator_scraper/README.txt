KickstarterGetCreator.R

Given a dataframe with columns for Kickstarter project names and their unique ID's, connect to Kickstarter and retrieve
additional information, including the project's creator.

== Dependecies ==
rPython R package
Python 2.7*
requests Python package

* The Python code should be mostly compatible with Python 3, but it seems that rPython does not support that yet.

== Running ==
The project comes with a Python virtualenv, and should be executed from inside that.

From your system's shell, cd to the directory containing this file and:
    venv/bin/activate
    R --vanilla < KickstarterGetCreator.R
