import re

words_collection = {}
disallowed = ["and", "the", "to", "are", "you", "for", "in", "i", "an", "a", "with", "on", "we", "it", "this", "from",
              "of", "by", "that", "be", "is"]

# errors="ignore" is needed as some of the blurbs contain non-valid UTF-8 characters
with open("blurbs.txt", errors="ignore") as input_file:
    for line in input_file:
        words = line.strip().split(' ');
        for word in words:
            word = word.lower()
            word = re.sub("[^A-Za-z0-9]", "", word)
            if word == '':
                continue
            if word in disallowed:
                continue
            if word in words_collection:
                words_collection[word] += 1
            else:
                words_collection[word] = 1

with open("wordcounts.csv", "w") as output_file:
    for key in words_collection.keys():
        output_file.write(key + ',' + str(words_collection[key]) + "\n")
