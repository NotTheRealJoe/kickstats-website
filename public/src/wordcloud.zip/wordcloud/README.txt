wordcloud

From the blurbs scraped from Kickstarter in our dataframe, generate a wordcloud image based on the frequency of each
word.

This program is divided into three parts in order to deal with a very large number of words. They are described here in
the order that they must be executed:

wordCloudExport.R
Reads the blurbs column from the R data file, and saves all the blurbs to a plain text file, one blurb per line.

CountWordsJoe.py
Reads in the plain text file generated above, and tallies up the frequency for each word. It is also in this file that
we filter out what exactly a word should be. Several common words (e.g. "and" and "the") are excluded, and we also strip
any characters that are not a latin letter, a numeral, or a space. The space is then used for the delimited between
words. As such, words containing punctuation (e.g. "don't") are still counted, but will be displayed in the word cloud
with the punctuation stripped. Once the tallying is complete, a CSV file is written with each word in the first column
and its frequency in the second.

wordCloud.R
Reads in the CSV data generated above and does the actual generation of the word cloud.
