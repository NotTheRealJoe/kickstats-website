#load("KickstarterData.rdata")

write.table(k2018_new[which(!is.na(k2018_new$blurb) & k2018_new$usdPledged < k2018_new$usdGoal), "blurb"], file = "blurbs_fail.txt", row.names = FALSE, col.names = FALSE)
