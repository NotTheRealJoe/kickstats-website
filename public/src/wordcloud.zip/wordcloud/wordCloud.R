#install.packages("wordcloud", dependencies = TRUE)
#install.packages("RColorBrewer", dependencies = TRUE)

library(wordcloud)
library(RColorBrewer)

wordFreqs <- read.csv("../CountWords/wordcounts_fail.csv")
colnames(wordFreqs) <- c("word","freq")

png("wordcloud_fail.png")
wordcloud(wordFreqs$word, wordFreqs$freq, min.freq = 500, max.words = 10000, random.order = FALSE, colors = brewer.pal(8, "Dark2"), use.r.layout = FALSE)
dev.off()